
# SolGlitch — Farcaster Frame x Solana

Une Frame Farcaster dynamique qui génère un projet dev+ imaginaire et interagit avec Solana devnet.

## Déploiement

1. `npm install`
2. Déploie sur Vercel via GitHub
3. Poste le lien `https://solglitch.vercel.app` dans Warpcast avec `/cast-frame`

## Technologies
- Node.js (Vercel Edge)
- Solana Web3.js
- Farcaster Frame spec JSON
