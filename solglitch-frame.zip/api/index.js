
export default async function handler(req, res) {
  res.status(200).json({
    name: "SolGlitch",
    description: "glitchmancer.sol — built on Solana",
    image: "https://solglitch.vercel.app/glitch.png",
    buttons: [{ label: "→ Cast it onchain", action: "post", target: "/api/interact" }]
  });
}
