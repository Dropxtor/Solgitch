
import { Connection } from "@solana/web3.js";

export default async function handler(req, res) {
  const connection = new Connection("https://api.devnet.solana.com", "confirmed");
  console.log("Frame interaction received at", new Date().toISOString());

  // Interaction fictive (ping solana)
  const project = "glitchmancer.sol";
  const image = "https://solglitch.vercel.app/glitch.png";

  res.status(200).json({
    image,
    description: `${project} just pinged Solana devnet`,
    buttons: [{ label: "→ Reroll", action: "post", target: "/api/interact" }]
  });
}
